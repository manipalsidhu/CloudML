import "./Footer.css"

export default function Footer(){
    return(
        <div className = "mainfooter">
            <p>Copyright Cloud Machine Learning Group 5</p>
        </div>
    )
}